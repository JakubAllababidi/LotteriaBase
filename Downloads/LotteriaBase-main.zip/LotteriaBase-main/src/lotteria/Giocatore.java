/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package lotteria;

import java.util.Random;

/**
 *
 * @author monica ciuchetti
 */
public class Giocatore extends Thread{
    // attributi

    /**
    * 
    * Metodo costruttore
    * @param idGiocatore codice del giocatore
    * @param estrazione riferimento dell'oggetto Estrazione
    */
    public Giocatore(int idGiocatore, Estrazione estrazione) {
       // inizializzazione attributi
    }

    /**
    * 
    * Metodo per eseguire il thread
    */
    public void run() {
       // scela del numero da giocare
       // verifica del risutlato
       // stampa fine verifica
    }
}
